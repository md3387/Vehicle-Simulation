﻿import random
import pandas as pd
from enum import Enum
from datetime import datetime, timedelta
import uuid
import numpy as np
import math

try:
    from . import roads, vehicles
except ImportError:
    import roads, vehicles

class Convoy:
    def __init__(self, vehicles, road, **kwargs):
        self.id = kwargs.get("id", uuid.uuid1().hex)
        self.vehicles_by_id = {}
        self.vehicles = []
        
        self.approaching_from_rear = {}
        self.approaching_from_front = {}
        
        if vehicles:
            if isinstance(vehicles, (list, tuple, set)):
                self.vehicles = list(vehicles)
                self.vehicles_by_id = {v.id: v for v in vehicles}
            elif isinstance(vehicles, dict):
                self.vehicles = list(vehicles.values())
                self.vehicles_by_id = vehicles
                
        for vehicle in self.vehicles:
            vehicle.convoy = self
            vehicle.available_for_convoy = False
            
        self.road = road
        self._last_position = 0
        
        self.sort_vehicles()
        
        # cruise and overtake speeds in meters per second determined by vehicle condition, weight, slope, power
        self.cruise_multiplier = kwargs.get("convoy_cruise_multiplier", 0.2)
        self.cruise_speed = kwargs.get("convoy_cruise", 30)
        #self.max_speed = kwargs.get("single_vehicle_overtake", (self.cruise_speed * 1.2) + 5)
        
        self.convoy_gap=kwargs.get("convoy_gap", self.cruise_speed)
        
        self.convoy_overtake=kwargs.get("convoy_overtake", self.cruise_speed + 4)
        self.convoy_slowdown=kwargs.get("convoy_slowdown", self.cruise_speed - 4)
        self.convoy_adjustment=kwargs.get("convoy_adjustment", 3)
        self.max_convoy_vehicles=kwargs.get("max_convoy_vehicles", 1000)
        self.max_convoy_length=kwargs.get("max_convoy_length", 5000)
        
        self.speed = np.mean([v.speed for v in self.vehicles]) if self.vehicles else 0
        self.desired_speed = self.speed #self.max_speed * self.urgency
        self.available_for_merge = True
        
        self.start = kwargs.get("starttime", datetime.utcnow())
        
    def __len__(self):
        return len(self.vehicles)
    
    def add_vehicle(self, vehicle):
        #print(f"Adding vehicle {vehicle.id} to convoy {self.id}")
        self.vehicles_by_id[vehicle.id] = vehicle
        self.vehicles = list(self.vehicles_by_id.values())
        self.sort_vehicles()
        
        if vehicle.id in self.approaching_from_rear: del self.approaching_from_rear[vehicle.id]
        if vehicle.id in self.approaching_from_front: del self.approaching_from_front[vehicle.id]
            
        vehicle.convoy = self
        vehicle.desired_speed = self.desired_speed
        vehicle.available_for_convoy = False
        
    
    def remove_vehicle(self, vehicle):
        #print(f"Removing vehicle {vehicle.id} from convoy {self.id}")
        try:
            if vehicle.id in self.approaching_from_rear: del self.approaching_from_rear[vehicle.id]
            if vehicle.id in self.approaching_from_front: del self.approaching_from_front[vehicle.id]
            
            vehicle.convoy = None
            vehicle.desired_speed = min(vehicle.speed, vehicle.max_speed)
            
            del self.vehicles_by_id[vehicle.id]
            self.vehicles = list(self.vehicles_by_id.values())
            self.sort_vehicles()
            
        except:
            pass
    
    def sort_vehicles(self):
        if self.road.loop:
            self.vehicles.sort(key=lambda v: v.position + self.road.length if v.position < self.road.length / 2 else v.position)
        else:
            self.vehicles.sort(self.vehicles_by_id.values(), key=lambda v: v.position)
    
    @property
    def max_vehicles(self):
        if self.vehicles_by_ids:
            vehicle_lengths = sum([vehicle.length + gap for vehicle in self.vehicles_by_ids.values()])
            return min(self.max_convoy_vehicles, int((self.max_convoy_length - vehicle_lengths) / (5 + gap)))
        else:
            return min(self.max_convoy_vehicles, int(self.max_convoy_length / (5 + gap)))
    
    @property
    def position(self):
        if not self.vehicles:
            return self._last_position
        else:
            self._last_position = np.mean([v.position + self.road.length for v in self.vehicles]) % self.road.length
        return self._last_position
    
    @property
    def max_speed(self): # current maximum speed in meters per second determined by vehicle condition, accelation, weight, slope
        if not self.vehicles:
            return self.cruise_speed * (1 + math.log10(1)) * self.urgency
        return self.cruise_speed * (1 + math.log10(len(self.vehicles) ** 0.5)) * self.urgency
    
    @property
    def urgency(self):
        if not self.vehicles: return 1
        return np.mean([vehicle.urgency ** 0.5 for vehicle in self.vehicles_by_id.values()])
        
    @property
    def front(self):
        # the position of the front of the first vehicle for checking proximity to vehicles in front of the convoy
        if not self.vehicles: return self._last_position
        return max([vehicle.front for vehicle in self.vehicles_by_id.values()])
    
    @property
    def rear(self):
        # the position of the rear of the last vehicle for checking proximity to vehicles in back of the convoy
        if not self.vehicles: return self._last_position
        
        if self.road.loop and self.position > ((self.road.length / 2) + self.max_convoy_length):
            return min([vehicle.rear for vehicle in self.vehicles_by_id.values()])
            
        else:
            return min([vehicle.rear for vehicle in self.vehicles_by_id.values()])
    
    @property
    def length(self):
        # the back of the convoy to the front of the convoy
        if not self.vehicles: return 0.0
        if self.road.loop and self.position > ((self.road.length / 2) + self.max_convoy_length):
            if self.front < self.rear:
                return (self.front + self.road.length) - self.rear
            else:
                return self.front - self.rear
        else:
            return self.front - self.rear
    
    @property
    def spacing(self):
        if not self.vehicles: return []
        self.sort_vehicles()
        return [
            self.road.separation(vehicle2.position, vehicle1.position)
            for vehicle1, vehicle2 in zip(self.vehicles, self.vehicles[1:])
        ]
    
    @property
    def precise_spacing(self):
        if not self.vehicles: return []
        self.sort_vehicles()
        return [
            self.road.separation(vehicle2.rear, vehicle1.front)
            if vehicle2.position > vehicle1.position else
            self.road.separation(vehicle1.rear, vehicle2.front)
            for vehicle1, vehicle2 in zip(self.vehicles, self.vehicles[1:])
        ]
    
    @property
    def distance_from_center(self):
        if not self.vehicles: return []
        self.sort_vehicles()
        convoy_position = self.position
        return [
            self.road.separation(vehicle.position, convoy_position)
            for vehicle in self.vehicles
        ]
    
    def adjust_spacing(self, priority=None, per_gap_adjustment=0.5, **kwargs):
        gaps_being_adjusted = 0
        differential = 0
        
        if len(self.vehicles) < 2:
            # no gaps
            return gaps_being_adjusted, differential
        
        self.sort_vehicles()
        gaps = self.precise_spacing
        too_small = self.convoy_gap - .01
        too_big = self.convoy_gap + .01
        if max(gaps) <= too_big and min(gaps) >= too_small:
            # gaps are the right size
            return gaps_being_adjusted, differential
        
        vehicles_and_gaps = list(zip(self.vehicles, range(len(self.vehicles)), gaps, self.vehicles[1:]))
        
                
        if priority in {"forward", "front", "FORWARD", "FRONT"}:
            # close gaps by making vehicles move forward to match distance with the vehicle in front of them
            vehicles_and_gaps[-1][-1].desired_speed = self.desired_speed # set frontmost vehicle to convoy desired speed
            for rear_vehicle, gap_idx, gap, front_vehicle in reverse(vehicles_and_gaps):
                if too_small < gap < too_big:
                    rear_vehicle.desired_speed = front_vehicle.desired_speed # no adjustment needed on this gap. Make sure vehicle is going same speed as vehicle in front of it
                elif too_small >= gap: #gap is too small
                    gaps_being_adjusted += 1
                    if differential <= -self.convoy_adjustment:
                        rear_vehicle.desired_speed = front_vehicle.desired_speed # rear of convoy is already slowing down as much as it can. slow vehicle down to just match speed of vehicle in front
                    else:
                        adj = min(too_small - gap, per_gap_adjustment)
                        differential -= adj
                        rear_vehicle.desired_speed = front_vehicle.desired_speed - adj
                elif too_big <= gap:
                    gaps_being_adjusted += 1
                    if differential >= self.convoy_adjustment:  # rear of convoy is already speeding up as much as it can. speed vehicle up to just match speed of vehicle in front
                        rear_vehicle.desired_speed = front_vehicle.desired_speed
                    else:
                        adj = min(gap - too_big, per_gap_adjustment)
                        differential += adj
                        rear_vehicle.desired_speed = front_vehicle.desired_speed + adj
        
        elif priority in {"backward", "back", "BACKWARD", "BACK"}:
            # close gaps by making vehicles move backward to match distance with the vehicle in back of them
            vehicles_and_gaps[0][0].desired_speed = self.desired_speed # set rearmost vehicle to convoy desired speed
            for rear_vehicle, gap_idx, gap, front_vehicle in vehicles_and_gaps:
                if too_small < gap < too_big:
                    front_vehicle.desired_speed = rear_vehicle.desired_speed
                elif too_small >= gap: #gap is too small
                    gaps_being_adjusted += 1
                    if differential >= self.convoy_adjustment:
                        front_vehicle.desired_speed = rear_vehicle.desired_speed # rear of convoy is already slowing down as much as it can. slow vehicle down to just match speed of vehicle in front
                    else:
                        adj = min(too_small - gap, per_gap_adjustment)
                        differential += adj
                        front_vehicle.desired_speed = rear_vehicle.desired_speed + adj
                elif too_big <= gap:
                    gaps_being_adjusted += 1
                    if differential <= self.convoy_adjustment:  # rear of convoy is already speeding up as much as it can. speed vehicle up to just match speed of vehicle in front
                        front_vehicle.desired_speed = rear_vehicle.desired_speed
                    else:
                        adj = min(gap - too_big, per_gap_adjustment)
                        differential -= adj
                        front_vehicle.desired_speed = rear_vehicle.desired_speed - adj
        
        else: #priorty is center -> out
            # close gaps by making vehicles move in to match distance with the vehicle closer to the center of the convoy
            convoy_position = self.position
            distances_from_center = [
                self.road.separation(vehicle.position, convoy_position)
                for vehicle in self.vehicles
            ]
            vehicles_and_gaps = list(zip(self.vehicles, distances_from_center, range(len(self.vehicles)), gaps, distances_from_center[1:], self.vehicles[1:], ))
            
            vehicles_and_gaps.sort(
                key=lambda t: (
                    min(abs(t[1]), abs(t[4])),
                    max(abs(t[1]), abs(t[4]))
                )
            )
            #print(vehicles_and_gaps)
            
            if too_small < vehicles_and_gaps[0][3] < too_big:
                if kwargs.get("b_debug"):print("\t Center gap is fine")
                vehicles_and_gaps[0][-1].desired_speed = self.desired_speed
                vehicles_and_gaps[0][0].desired_speed = self.desired_speed
            else:
                if abs(vehicles_and_gaps[0][1]) >= abs(vehicles_and_gaps[0][4]):
                    if kwargs.get("b_debug"):print("\t Center-front vehicle is closest")
                    vehicles_and_gaps[0][-1].desired_speed = self.desired_speed
                else:
                    if kwargs.get("b_debug"):print("\t Center-rear vehicle is closest")
                    vehicles_and_gaps[0][0].desired_speed = self.desired_speed
            
            for rear_vehicle, rear_from_center, gap_idx, gap, front_from_center, front_vehicle in vehicles_and_gaps:
                if kwargs.get("b_debug"):
                    print({
                        "rear_vehicle": rear_vehicle,
                        "rear_from_center": rear_from_center,
                        "gap_idx": gap_idx,
                        "gap": gap,
                        "front_from_center": front_from_center,
                        "front_vehicle": front_vehicle,
                        "differential": differential,
                        "gaps_being_adjusted": gaps_being_adjusted,
                    })
                
                if abs(rear_from_center) >= abs(front_from_center):
                    #rear vehicle is further from center
    
                    if too_small < gap < too_big:
                        rear_vehicle.desired_speed = front_vehicle.desired_speed # no adjustment needed on this gap. Make sure vehicle is going same speed as vehicle in front of it
                        if kwargs.get("b_debug"):print("\t No adjustment to rear")
                    elif too_small >= gap: #gap is too small
                        gaps_being_adjusted += 1
                        if differential <= -self.convoy_adjustment:
                            rear_vehicle.desired_speed = front_vehicle.desired_speed # rear of convoy is already slowing down as much as it can. slow vehicle down to just match speed of vehicle in front
                            if kwargs.get("b_debug"):print("\t No adjustment to rear. Max differential")
                        else:
                            adj = min(too_small - gap, per_gap_adjustment)
                            differential -= adj
                            rear_vehicle.desired_speed = front_vehicle.desired_speed - adj
                            if kwargs.get("b_debug"):print("\t Slow rear vehicle down")
                    elif too_big <= gap:
                        gaps_being_adjusted += 1
                        if differential >= self.convoy_adjustment:  # rear of convoy is already speeding up as much as it can. speed vehicle up to just match speed of vehicle in front
                            rear_vehicle.desired_speed = front_vehicle.desired_speed
                            if kwargs.get("b_debug"):print("\t No adjustment to rear. Max differential")
                        else:
                            adj = min(gap - too_big, per_gap_adjustment)
                            differential += adj
                            rear_vehicle.desired_speed = front_vehicle.desired_speed + adj
                            if kwargs.get("b_debug"):print("\t Speed rear vehicle up")
                    
                else:
                    #front vehicle is further from center
                
                    if too_small < gap < too_big:
                        front_vehicle.desired_speed = rear_vehicle.desired_speed
                        if kwargs.get("b_debug"):print("\t No adjustment to front")
                    elif too_small >= gap: #gap is too small
                        gaps_being_adjusted += 1
                        if differential <= -self.convoy_adjustment:
                            front_vehicle.desired_speed = rear_vehicle.desired_speed # rear of convoy is already slowing down as much as it can. slow vehicle down to just match speed of vehicle in front
                            if kwargs.get("b_debug"):print("\t No adjustment to front. Max differential")
                        else:
                            adj = min(too_small - gap, per_gap_adjustment)
                            differential += adj
                            front_vehicle.desired_speed = rear_vehicle.desired_speed + adj
                            if kwargs.get("b_debug"):print("\t Speed front vehicle up")
                    elif too_big <= gap:
                        gaps_being_adjusted += 1
                        if differential >= self.convoy_adjustment:  # rear of convoy is already speeding up as much as it can. speed vehicle up to just match speed of vehicle in front
                            front_vehicle.desired_speed = rear_vehicle.desired_speed
                            if kwargs.get("b_debug"):print("\t No adjustment to front. Max differential")
                        else:
                            adj = min(gap - too_big, per_gap_adjustment)
                            differential -= adj
                            front_vehicle.desired_speed = rear_vehicle.desired_speed - adj
                            if kwargs.get("b_debug"):print("\t Slow front vehicle down")
            
        return gaps_being_adjusted, differential
    
    def __repr__(self):
        if isinstance(self.road, roads.EntranceRamp):
            s = f"""{self.vehicle_type} at {self.position:,}m on entrance ramp {self.road.id} on road {self.road.parent.id} at {self.road.position/1000:0.1f}km."""
        elif isinstance(self.road, roads.ExitRamp):
            s = f"""{self.vehicle_type} at {self.position:,}m on exit ramp {self.road.id} on road {self.road.parent.id} at {self.road.position/1000:0.1f}km"""
        else:
            s = f"""Convoy {self.id} at {self.position/1000:0.1f}km on road {self.road.id}. Vehicles:{len(self.vehicles_by_id)}"""
        return s


def merge_convoys(*convoys, e_convoys=None):
    if not convoys: return None
    a_convoy_roads = [convoy.road for convoy in convoys]
    assert len(set([road.id for road in a_convoy_roads])) == 1
    road = a_convoy_roads[0]
    
    
    vehicles = [vehicle for convoy in convoys for vehicle in convoy.vehicles_by_id.values()]
    new_convoy = Convoy(
        vehicles=vehicles,
        road=road,
        convoy_cruise_multiplier=min([convoy.cruise_multiplier for convoy in convoys]),
        convoy_cruise=min([convoy.cruise_speed for convoy in convoys]),
        convoy_gap=max([convoy.convoy_gap for convoy in convoys]),
        convoy_overtake=min([convoy.convoy_overtake for convoy in convoys]),
        convoy_slowdown=min([convoy.convoy_slowdown for convoy in convoys]),
        convoy_adjustment=min([convoy.convoy_adjustment for convoy in convoys]),
        
        max_convoy_vehicles=min([convoy.max_convoy_vehicles for convoy in convoys]),
        max_convoy_length=min([convoy.max_convoy_length for convoy in convoys]),
    )
    new_convoy.start = min([convoy.start for convoy in convoys])
    for vehicle in vehicles:
        vehicle.convoy = new_convoy
    
    #print(f"Merging convoys [{', '.join([t.id for t in convoys])}] into new convoy {new_convoy.id}")
    
    for convoy in convoys:
        convoy.road.remove_convoy(convoy)
        if e_convoys:
            try:
                del e_convoys[convoy.id]
            except:
                pass
    road.add_convoy(new_convoy)
    if e_convoys:
        e_convoys[new_convoy.id] = new_convoy
    
    return new_convoy

