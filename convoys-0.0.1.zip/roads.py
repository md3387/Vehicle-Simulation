﻿import random
import pandas as pd
from enum import Enum
from datetime import datetime, timedelta
import uuid
import numpy as np
import math


class RoadSegment:
    def __init__(self, **kwargs):
        self.segment_type = "Pavement"
        self.id = kwargs.get("id", uuid.uuid1().hex)
        self.vehicles_by_id = {}
        self.vehicles = []
        self.convoys_by_id = {}
        self.convoys = []
        
        self.ramps_by_id = {}
        self.exit_ramps = []
        self.entrance_ramps = []
        
        #self.parent = kwargs.get("parent", None) # object of parent road segment
        #self.position = kwargs.get("position", 0) # terminus of connection to parent road segment
        
        # object of road segment connected to this road's start
        self.start_terminus = kwargs.get("start_terminus", None)
        self.start_position = kwargs.get("start_position", 0)
        
        # object of road segment connected to this road's end
        self.end_terminus = kwargs.get("end_terminus", None)
        self.end_position = kwargs.get("end_position", 0)
        
        self.length = kwargs.get("length", 10000) # length of segment in meters
        self.loop = kwargs.get("circular", False) # whether the road is a closed loop
    
    def __repr__(self):
        s = f"""{self.segment_type}({self.id})"""
        #if self.parent:
        #    s += f""" on road {self.parent.id}."""
        if self.start_terminus:
            s += f""" starts from road {self.start_terminus.id} at {self.start_position/1000:0.1f}km."""
        if self.end_terminus:
            s += f""" ends on road {self.end_terminus.id} at {self.end_position/1000:0.1f}km."""
        if self.vehicles_by_id:
            s += f""" {len(self.vehicles_by_id):,} vehicles."""
        if self.convoys_by_id:
            s += f""" {len(self.convoys_by_id):,} convoys."""
        if self.exit_ramps:
            s += f""" {len(self.exit_ramps):,} exit ramps."""
        if self.entrance_ramps:
            s += f""" {len(self.entrance_ramps):,} entrance ramps."""
        return s
    
    def separation(self, x, y):
        if self.loop:
            return (x - y) if abs(x - y) < (self.length / 2) else  ((self.length - y) + x)
        else:
            return y - x
    
    def moving_vehicles(self):
        return [vehicle for vehicle in self.vehicles_by_id.values() if vehicle.speed > 0]
    
    def remove_vehicle(self, vehicle):
        if vehicle.id in self.vehicles_by_id: del self.vehicles_by_id[vehicle.id]
        for i, x in enumerate(self.vehicles): 
            if x.id == vehicle.id:
                self.vehicles.pop(i)
                break
        
    def add_vehicle(self, vehicle):
        self.vehicles_by_id[vehicle.id] = vehicle
        self.vehicles.append(vehicle)
    
    def sort_vehicles(self):
        if self.road.loop:
            self.vehicles.sort(key=lambda v: v.position + self.length if v.position < self.length / 2 else v.position)
        else:
            self.vehicles.sort(self.vehicles_by_id.values(), key=lambda v: v.position)
        
    def remove_convoy(self, convoy):
        if convoy.id in self.convoys_by_id: del self.convoys_by_id[convoy.id]
        for i, x in enumerate(self.convoys): 
            if x.id == convoy.id:
                self.convoys.pop(i)
                break
        
    def add_convoy(self, convoy):
        self.convoys_by_id[convoy.id] = convoy
        self.convoys.append(convoy)

    def sort_convoys(self):
        if self.road.loop:
            self.convoys.sort(key=lambda v: v.position + self.length if v.position < self.length / 2 else v.position)
        else:
            self.convoys.sort(self.convoys_by_id.values(), key=lambda v: v.position)
        

class EntranceRamp(RoadSegment):
    def __init__(self, parent, position, exit=None, **kwargs):
        if "length" not in kwargs: kwargs["length"] = 400
            
        super().__init__(parent=parent, position=position, **kwargs)
        self.segment_type = "EntranceRamp"
        self.end_terminus = parent
        self.end_position = position
        
        self.exit = exit # id/object of matching exit ramp
    
        

class ExitRamp(RoadSegment):
    def __init__(self, parent, position, entrance=None, **kwargs):
        if "length" not in kwargs: kwargs["length"] = 400
            
        super().__init__(parent=parent, position=position, **kwargs)
        self.segment_type = "ExitRamp"
        self.start_terminus = parent
        self.start_position = position
        
        self.entrance = entrance # id/object of matching entrance ramp
    
        
    

class Road(RoadSegment):
    def __init__(self, **kwargs):
        if "length" not in kwargs: kwargs["length"] = 10000
        
        super().__init__(**kwargs)
        self.segment_type = f"{self.length/1000:0.1f}km-{'Circular_' if self.loop else ''}Road"
        
        self.ramps_by_id = {}
        self.exit_ramps = []
        self.entrance_ramps = []
    
#    def __repr__(self):
#        s = f"""{self.segment_type}({self.id})."""
#        if self.start_terminus:
#            s += f""" starts from road {self.start_terminus.id}."""
#        if self.end_terminus:
#            s += f""" ends on road {self.end_terminus.id}."""
#        if self.vehicles_by_id:
#            s += f""" {len(self.vehicles_by_id):,} vehicles."""
#        if self.convoys_by_id:
#            s += f""" {len(self.convoys_by_id):,} convoys."""
#        if self.exit_ramps:
#            s += f""" {len(self.exit_ramps):,} exit ramps."""
#        if self.entrance_ramps:
#            s += f""" {len(self.entrance_ramps):,} entrance ramps."""
#        return s
    
