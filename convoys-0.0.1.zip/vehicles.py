﻿import random
import pandas as pd
from enum import Enum
from datetime import datetime, timedelta
import uuid
import numpy as np
import math

try:
    from . import roads
except ImportError:
    import roads

class VehicleBodyTypes(Enum):
    motorcycle = 0
    sedan = 1
    wagon = 2
    suv = 3
    minivan = 4
    van = 5
    pickup = 6
    heavy_duty_pickup = 7
    city_bus = 8
    touring_bus = 9
    semi = 10

class Vehicle:
    def __init__(self, **kwargs):
        self.id = kwargs.get("id", uuid.uuid1().hex)
        self.origination = None
        self.destination = None
        
        
        if isinstance(kwargs.get("origin"), (roads.EntranceRamp, roads.Road)):
            self.origination = kwargs["origin"]
            #print(self.origination)
        #else:
        #    self.origination = ENTRANCE_RAMPS[kwargs.get("origin", random.randint(0, len(ENTRANCE_RAMPS) - 1))] # entrance ramp object
        
        if isinstance(kwargs.get("destination"), roads.ExitRamp):
            self.destination = kwargs["destination"]
        #else:
        #    self.destination = EXIT_RAMPS[kwargs["destination"]] if kwargs.get("destination", None) else None # exit ramp object
        
        self.vehicle_type = kwargs.get("vehicle_type", VehicleBodyTypes.sedan)
        #print(self.vehicle_type)
        if self.vehicle_type in {VehicleBodyTypes.semi}:
            self.length = kwargs.get("length", 14.5 + random.random() * 7.5) # vehicle length in meters
            self.height = kwargs.get("height", 3.5 + random.random() * 0.6) # vehicle height in meters
            self.width = kwargs.get("width", 2.45) # vehicle width in meters
            self.weight = kwargs.get("weight", 12.5 + random.random() * 27.5) # vehicle weight in kilograms
        elif self.vehicle_type in {VehicleBodyTypes.touring_bus, VehicleBodyTypes.city_bus,}:
            self.length = kwargs.get("length", 10 + random.random() * 2) # vehicle length in meters
            self.height = kwargs.get("height", 3 + random.random() * 0.8) # vehicle height in meters
            self.width = kwargs.get("width", 2.45 + random.random() * 0.1) # vehicle width in meters
            self.weight = kwargs.get("weight", 12.5 + random.random() * 12.5) # vehicle weight in kilograms
            
        elif self.vehicle_type in {VehicleBodyTypes.pickup, VehicleBodyTypes.heavy_duty_pickup, VehicleBodyTypes.minivan, VehicleBodyTypes.van, VehicleBodyTypes.suv, }:
            self.length = kwargs.get("length", 4 + random.random() * 2.5) # vehicle length in meters
            self.height = kwargs.get("height", 1.75 + random.random() * 0.5) # vehicle height in meters
            self.width = kwargs.get("width", 1.9 + random.random() * 0.3) # vehicle width in meters
            self.weight = kwargs.get("weight", 2 + random.random() * 0.2) # vehicle weight in kilograms
        elif self.vehicle_type in {VehicleBodyTypes.wagon, VehicleBodyTypes.sedan}:
            self.length = kwargs.get("length", 3.5 + random.random() * 1) # vehicle length in meters
            self.height = kwargs.get("height", 1.4 + random.random() * 0.2) # vehicle height in meters
            self.width = kwargs.get("width", 1.8 + random.random() * 0.3) # vehicle width in meters
            self.weight = kwargs.get("weight", 1.4 + random.random() * 0.5) # vehicle weight in kilograms
        
        self.cross_section = self.height * self.width # vehicle width in meters
                                      
        self.urgency = 0.75 + random.random() * 0.25 # factor between 0 and 1 in how much a vehicle prioritizes joining a convoy vs driving at their max single-vehicle safe speed
        
        self.road = self.origination # id/object of road segment
        self.position = 0 # position along road segment
        
        self.convoy = None
        self.available_for_convoy = False # set to false when reaching destination to separate vehicle from convoy
        
        # current maximum cruise and overtake speeds in meters per second determined by vehicle condition, weight, slope, power
        self.cruise_speed = kwargs.get("single_vehicle_cruise", 30)
        self.max_speed = kwargs.get("single_vehicle_overtake", (self.cruise_speed * 1.2) + 5)
        
        self.speed = 0 # current speed in meters per second
        self.desired_speed = self.cruise_speed * self.urgency
        
        # eventually need to become calculations based on weight, power/torque, traction, slope
        self.acceleration = 3 + random.random() * 1.5 # ability to speed up in meters per second per second
        self.deacceleration = 5 + random.random() * 4.8 # ability to slow down in meters per second per second
        
        # factor of fuel efficiency that comes from air drag coefficient and impact how much vehicle benefits from tailing convoy
        #https://phas.ubc.ca/~james/teaching/phys333/module4_lesson3.pdf
        if self.vehicle_type in {VehicleBodyTypes.semi, VehicleBodyTypes.touring_bus, VehicleBodyTypes.city_bus, VehicleBodyTypes.van, }:
            self.drag_coefficient = 0.5 + random.random() * 0.4
        elif self.vehicle_type in {VehicleBodyTypes.pickup, VehicleBodyTypes.heavy_duty_pickup, VehicleBodyTypes.suv}:
            self.drag_coefficient = 0.45 + random.random() * 0.1
        elif self.vehicle_type in {VehicleBodyTypes.suv, VehicleBodyTypes.wagon}:
            self.drag_coefficient = 0.35 + random.random() * 0.1
        elif self.vehicle_type in {VehicleBodyTypes.sedan}:
            self.drag_coefficient = 0.25 + random.random() * 0.1
        elif self.vehicle_type in {VehicleBodyTypes.motorcycle}:
            self.drag_coefficient = 0.5 + random.random() * 0.5
        
        #https://x-engineer.org/rolling-resistance/
        self.rolling_drag = .013 # factor of fuel efficiency that comes from rolling drag, independent of joining convoy
        
        #self.drive_resistance = 0 # factor of fuel efficiency that comes from the power convoy, independent of joining convoy
        self.cruise_kpl = 0 # fuel efficiency in kilometers per liter at cruise speed
        
        #other theoretical sensors/cpu
        #proximity distance ahead
        #proximity distance behind
        #tire pressure (rolling drag)
        
        self.traction = 1
        self.visibility = 1
    
    @property
    def front(self):
        # the position of the front of the vehicle for checking proximity to vehicles in front of this one
        return self.position + (self.length / 2)
    
    @property
    def rear(self):
        # the position of the rear of the vehicle for checking proximity to vehicles in back of this one
        return self.position - (self.length / 2)
    
    @property
    def max_safe_speed(self):
        #factors
            #brightness (visibility)
            #temperature (visbility and traction)
            #precipitation (visibility and traction)
            #abs (traction)
        # current maximum overtake speed in meters per second eventually determined by road and vehicle condition
        return self.max_speed * min(self.traction, self.visibility)
    
    @property
    def max_cruise_speed(self):
        #factors
            #brightness (visibility)
            #temperature (visbility and traction)
            #precipitation (visibility and traction)
            #abs (traction)
        # current maximum speed in meters per second eventually determined by road and vehicle condition
        return self.cruise_speed * min(self.traction, self.visibility)
    
    def __repr__(self):
        if isinstance(self.road, roads.EntranceRamp):
            s = f"""{self.vehicle_type} at {self.position:,}m on entrance ramp {self.road.id} on road {self.road.end_terminus.id} at {self.road.end_position/1000:0.1f}km."""
        elif isinstance(self.road, roads.ExitRamp):
            s = f"""{self.vehicle_type} at {self.position:,}m on exit ramp {self.road.id} on road {self.road.start_terminus.id} at {self.road.start_position/1000:0.1f}km"""
        else:
            s = f"""{self.vehicle_type} at {self.position/1000:0.1f}km on road {self.road.id}. Urgency:{self.urgency:0.2f}, Available:{self.available_for_convoy}"""
        return s

