﻿import random
import pandas as pd
from enum import Enum
from datetime import datetime, timedelta
import uuid
import numpy as np
import math

try:
    from . import roads, vehicles, convoys
except ImportError:
    import roads, vehicles, convoys



class Simulator:
    default_road_length = 10000
    default_circular = False
    default_ramp_length = 400
    min_exit_separation = 800
    default_exit_separation = 3200
    max_exit_separation = 6400
    
    
    def __init__(self, **kwargs):
        # how close vehicles get before starting to cooperate to join convoys
        self.coordination_distance = kwargs.get("coordination_distance", 2000) # meters
        
        # how close vehicles have to get before being considered joined to the convoy
        self.convoy_margin = kwargs.get("convoy_margin", 100) # meters
        
        # how much faster a vehicle can temporarily go in order to catch up with a convoy
        self.coordination_overtake = 5 # m/s
        
        # speed for single vehicles to cruise at
        self.single_vehicle_cruise = kwargs.get("single_vehicle_cruise", 30) # m/s
        
        # speed for convoy to cruise at
        self.convoy_cruise_multiplier = kwargs.get("convoy_cruise_multiplier", 0.2) # % above single vehicle cruise
        self.convoy_cruise = kwargs.get("convoy_cruise", self.single_vehicle_cruise * (1 + self.convoy_cruise_multiplier)) # m/s
        
        # speed for single vehicles to overtake nearby convoys at
        self.single_vehicle_overtake = kwargs.get("single_vehicle_overtake", self.convoy_cruise + 6) # m/s
        
        # speed for convoys vehicles to overtake other nearby convoys at
        self.convoy_overtake = kwargs.get("convoy_overtake", self.convoy_cruise + 4) # m/s
        
        # speed for convoys vehicles to let other nearby convoys overtake them
        self.convoy_slowdown = kwargs.get("convoy_slowdown", self.convoy_cruise - 4) # m/s
        
        # speed for convoys vehicles to adjust the gaps between them
        self.convoy_adjustment = kwargs.get("convoy_adjustment", 3) # m/s
        
        # target meters between convoy vehicles
        self.convoy_gap = kwargs.get("convoy_gap", self.convoy_cruise / 2)
        
        # max length of convoy
        self.max_convoy_length = kwargs.get("max_convoy_length", self.coordination_distance)
        self.max_convoy_vehicles = kwargs.get("max_convoy_vehicles", 1000)
        
        self.roads = []
        self.entrance_ramps = []
        self.exit_ramps = []
        self.vehicles = []
        self.convoys = []
        self.vehicles_by_id = {}
        self.convoys_by_id = {}
        self.vehicle_index = {}
        self.convoy_index = {}
        
        self._step, self._time = 0, 0.0
        
    def initialize_roads(self, **kwargs):
        self.roads = []
        self.entrance_ramps = []
        self.exit_ramps = []
        
        num_roads = kwargs.get("num_roads", 1)
        
        if kwargs.get("road_lengths") is None or isinstance(kwargs.get("road_lengths", self.default_road_length), (int, float)):
            road_lengths = [kwargs.get("road_lengths", self.default_road_length)] * num_roads
        else:
            road_lengths = list(kwargs["road_lengths"])
            if len(road_lengths) < num_roads:
                road_lengths.extend(road_lengths[-1] * (num_roads - len(road_lengths)))
        
        if kwargs.get("roads_circular") is None or isinstance(kwargs.get("roads_circular", self.default_circular), bool):
            road_circulars = [kwargs.get("roads_circular", self.default_circular)] * num_roads
        else:
            road_circulars = list(kwargs["roads_circular"])
            if len(road_circulars) < num_roads:
                road_circulars.extend(road_circulars[-1] * (num_roads - len(road_circulars)))
        
        
        for i, length, circular  in zip(range(num_roads), road_lengths, road_circulars):
            self.roads.append(roads.Road(length=length, circular=circular, **kwargs))
        
        for road in self.roads:
            max_exits = kwargs.get("max_exits", round(road.length / self.default_exit_separation))
        
            next_exit = max(self.default_ramp_length, random.randint(self.min_exit_separation, self.max_exit_separation))
            while len(road.exit_ramps) < max_exits and next_exit <= road.length - self.default_ramp_length:
                
                exit = roads.ExitRamp(
                    parent=road,
                    position=(
                        max(0, (next_exit - self.default_ramp_length) % road.length)
                        if (next_exit - self.default_ramp_length) % road.length > 0 or not road.loop
                        else (next_exit - self.default_ramp_length) + road.length
                    ),
                )
                entrance = roads.EntranceRamp(
                    parent=road,
                    position=(next_exit + self.default_ramp_length) % road.length,
                )
                
                entrance.exit = exit
                exit.entrance = entrance
                
                self.entrance_ramps.append(entrance)
                self.exit_ramps.append(exit)
                
                road.ramps_by_id[entrance.id] = entrance
                road.entrance_ramps.append(entrance)
                
                road.ramps_by_id[exit.id] = exit
                road.exit_ramps.append(exit)
                
                next_exit += random.randint(self.min_exit_separation, self.max_exit_separation)
        
        #print(self.roads)
        return self.roads
    
    def initialize_vehicles(self, **kwargs):
        self.vehicles = []
        self.convoys = []
        self.vehicles_by_id = {}
        self.convoys_by_id = {}
        self.arrived_vehicles = {}
        
        for road in self.entrance_ramps + self.exit_ramps + self.roads:
            road.vehicles = []
            road.vehicles_by_id = {}
            road.convoys = []
            road.convoys_by_id = {}
        
        num_vehicles = kwargs.get("num_vehicles", 10)
        vehicles_types = kwargs.get("vehicles_types", [1, 1, 1, 2, 3, 3, 4, 6, 6, 7, 10, 10])
        
        # spawn vehicles at random entrance ramps in the simulation
        for i in range(num_vehicles):
            ramp = random.choice(self.entrance_ramps)
            destination = random.choice(self.exit_ramps) if random.random() > kwargs.get("destination_probability", 0.5) else None
            
            vehicle = vehicles.Vehicle(
                vehicle_type=vehicles.VehicleBodyTypes(random.choice(vehicles_types)),
                origin=ramp,
                destination=destination,
                single_vehicle_cruise=self.single_vehicle_cruise,
                single_vehicle_overtake=self.single_vehicle_overtake,
            )
            self.add_vehicle(vehicle)
            ramp.add_vehicle(vehicle)
            #print(vehicle)
        
        return self.vehicles
    
    def add_vehicle(self, vehicle):
        self.vehicles_by_id[vehicle.id] = vehicle
        self.vehicles.append(vehicle)
        self.vehicle_index[vehicle.id] = len(self.vehicle_index)
    
    def remove_vehicle(self, vehicle, **kwargs):
        vehicle_id = vehicle.id if isinstance(vehicle, vehicles.Vehicle) else vehicle
        if vehicle_id in self.vehicles_by_id:
            del self.vehicles_by_id[vehicle_id]
            
        i = 0
        while i < len(self.vehicles) and self.vehicles:
            if self.vehicles[i].id == vehicle_id:
                self.vehicles.pop(i)
                break
            i += 1
    
    def add_convoy(self, convoy):
        self.convoys_by_id[convoy.id] = convoy
        self.convoys.append(convoy)
        self.convoy_index[convoy.id] = len(self.convoy_index)
    
    def remove_convoy(self, convoy, **kwargs):
        convoy_id = convoy.id if isinstance(convoy, convoys.Convoy) else convoy
        if convoy_id in self.convoys_by_id:
            del self.convoys_by_id[convoy_id]
            
        i = 0
        while i < len(self.convoys) and self.convoys:
            if self.convoys[i].id == convoy_id:
                self.convoys.pop(i)
                break
            i += 1
    
    def vehicle_logic(self, time_step_seconds=1, **kwargs):
        c_checked = set()
        
        for vehicle in list(self.vehicles):
            if vehicle.id in self.arrived_vehicles: continue
            
            # add check to space vehicles out from on ramp
            if vehicle.speed == 0 and isinstance(vehicle.road, roads.EntranceRamp):
                ramp_moving_vehicles = vehicle.road.moving_vehicles()
                if ramp_moving_vehicles and min([vehicle.position for vehicle in ramp_moving_vehicles]) < self.single_vehicle_cruise * 2:
                    continue # wait turn to get going
            
            elif vehicle.speed == 0 and isinstance(vehicle.road, roads.ExitRamp):
                continue # already arrived, ignore
            
            # move vehicles
            if vehicle.speed < vehicle.desired_speed:
                vehicle.speed = min(vehicle.desired_speed, vehicle.speed + vehicle.acceleration)
            elif vehicle.speed > vehicle.desired_speed:
                vehicle.speed = max(vehicle.desired_speed, vehicle.speed - vehicle.deacceleration)
            
            if vehicle.speed == 0 and vehicle.desired_speed == 0 and (isinstance(vehicle.road, roads.ExitRamp) or (isinstance(vehicle.road, roads.Road) and not vehicle.road.loop)):
                vehicle.position = vehicle.road.length
                self.arrived_vehicles[vehicle.id] = vehicle
                #del self.vehicles[vehicle.id]
            
            new_position = vehicle.position + (vehicle.speed * time_step_seconds)
    
            if new_position >= vehicle.road.length:
                if isinstance(vehicle.road, roads.EntranceRamp):
                    # switch vehicle from on ramp to road
                    vehicle.position = vehicle.road.end_position + (new_position - vehicle.road.length)
                    ramp = vehicle.road
                    road = ramp.end_terminus
                    ramp.remove_vehicle(vehicle)
                    road.add_vehicle(vehicle)
                    vehicle.road = road
                    
                    vehicle.available_for_convoy = True
                    #print(f"Vehicle {vehicle.id} merged from entrance {ramp.id} onto road  {ramp.id}")
    
                elif isinstance(vehicle.road, roads.Road):
                    if vehicle.road.loop:
                        vehicle.position = new_position % vehicle.road.length
                    else:
                        vehicle.position = road.length
                        vehicle.speed = 0
                        vehicle.desired_speed = 0
                        
                        vehicle.road.remove_vehicle(vehicle)
                        if vehicle.convoy:
                            vehicle.convoy.remove_vehicle(vehicle)
                    
                        self.arrived_vehicles[vehicle.id] = vehicle
                    #self.remove_vehicle(vehicle)
    
                elif isinstance(vehicle.road, roads.ExitRamp):
                    ramp = vehicle.road
                    vehicle.position = ramp.length
                    vehicle.speed = 0
                    vehicle.desired_speed = 0
                    if vehicle.convoy:
                        vehicle.convoy.remove_vehicle(vehicle)
                    self.arrived_vehicles[vehicle.id] = vehicle
                    #self.remove_vehicle(vehicle)
    
            else:
                vehicle.position = new_position
            
            #print(t, vehicle)
            
            # check for arriving
            if vehicle.destination and vehicle.road.id == vehicle.destination.start_terminus.id:
                if abs(((vehicle.position + 1000) % vehicle.road.length) - vehicle.destination.start_position) < 100:
                    #nearing exit, no longer available to join convoy
                    vehicle.available_for_convoy = False
    
                if abs((vehicle.destination.start_position % vehicle.road.length) - (vehicle.position % vehicle.road.length)) < 100:
                    #at exit. Leave convoy
                    
                    print(f"S{self._step}/T{self._time} Vehicle {vehicle.id} reaching destination {vehicle.destination.id}")
                    if vehicle.convoy: vehicle.convoy.remove_vehicle(vehicle)
                    
                    vehicle.available_for_convoy = False
                    
                    vehicle.desired_speed = 0
                    vehicle.road.remove_vehicle(vehicle)
                    vehicle.destination.add_vehicle(vehicle)
                    
                    self.arrived_vehicles[vehicle.id] = vehicle
    
            nearby_convoy = False
            nearby_vehicles = []
            if not vehicle.convoy and vehicle.available_for_convoy:
                for convoy in vehicle.road.convoys_by_id.values():
                    front_distance = vehicle.road.separation(vehicle.position, convoy.front)
                    rear_distance = vehicle.road.separation(vehicle.position, convoy.rear)
                    if min(abs(front_distance), abs(rear_distance)) <= self.coordination_distance: # convoy is near vehicle
                        nearby_convoy = True
                        #print("nearby_convoy", convoy)
                        if (abs(front_distance) < self.convoy_margin or abs(rear_distance) < self.convoy_margin) or (front_distance > 0 and rear_distance < 0): # vehicle is in position to join convoy already
                            #vehicle.available_for_convoy = False
                            convoy.add_vehicle(vehicle)
                            print(f"S{self._step}/T{self._time} Adding vehicle {vehicle.id} to convoy {convoy.id}")
                            break
                            
                        elif front_distance < 0: # front of convoy is behind vehicle
                            vehicle.desired_speed = min(convoy.desired_speed + self.coordination_overtake, self.single_vehicle_overtake, vehicle.max_safe_speed)
                            convoy.approaching_from_front[vehicle.id] = vehicle
                            break
                        
                        elif rear_distance > 0 and vehicle.max_speed > convoy.convoy_slowdown: # rear of convoy is ahead of vehicle
                            vehicle.desired_speed = vehicle.max_speed
                            convoy.approaching_from_rear[vehicle.id] = vehicle
                            break
                
                if not nearby_convoy:
                    nearby_vehicles = []
                    for other in vehicle.road.vehicles_by_id.values():
                        if other.id in c_checked or other.id in self.arrived_vehicles: continue
                        
                        if not other.available_for_convoy or other.convoy or vehicle.id == other.id: continue
                        
                        #print(vehicle.id, other.id)
                        distance = vehicle.road.separation(vehicle.position, other.position)
                        if abs(distance) <= self.coordination_distance: # other is near vehicle
                            nearby_vehicles.append(other)
                        
                    if nearby_vehicles:
                        #raise Exception("nearby_vehicles")
                        #print("nearby_vehicles", nearby_vehicles)
                        nearby_vehicles.append(vehicle)
                        
                        convoy = convoys.Convoy(
                            vehicles=nearby_vehicles,
                            road=vehicle.road,
                            convoy_cruise_multiplier=self.convoy_cruise_multiplier,
                            convoy_cruise=self.convoy_cruise,
                            convoy_gap=self.convoy_gap,
                            convoy_overtake=self.convoy_overtake,
                            convoy_slowdown=self.convoy_slowdown,
                            convoy_adjustment=self.convoy_adjustment,
                            max_convoy_vehicles=self.max_convoy_vehicles,
                            max_convoy_length=self.max_convoy_length,
                        )
                        print(f"S{self._step}/T{self._time} Creating convoy of {len(nearby_vehicles):,} vehicles {convoy.id}")
                        print(f"\t[{', '.join(v.id for v in nearby_vehicles)}]")
                        # let desired speed be adjusted on the next loop after it checks its surroundings
                        #convoy.desired_speed = np.mean([v.speed for v in nearby_vehicles])
                        
                        vehicle.road.add_convoy(convoy)
                        
                        for v in convoy.vehicles:
                            v.convoy = convoy
                            #x.desired_speed = convoy.desired_speed
                            v.available_for_convoy = False
                        self.add_convoy(convoy)
                        
                        c_checked.update(v.id for v in nearby_vehicles)
            c_checked.add(vehicle.id)
    
    def convoy_logic(self, **kwargs):
        c_merged = set()
        for convoy in list(self.convoys):
            if convoy.id in c_merged: continue
            if convoy.approaching_from_rear:
                #print("approaching_from_rear")
                
                # go slow so vehicles can catch up
                convoy.desired_speed = self.convoy_slowdown
                for vehicle in convoy.vehicles_by_id.values():
                    vehicle.desired_speed = convoy.desired_speed
            elif convoy.approaching_from_front:
                # nearby vehicles are in front so speed up
                convoy.desired_speed = convoy.max_speed
                for vehicle in convoy.vehicles_by_id.values():
                    vehicle.desired_speed = convoy.desired_speed
            else:
                nearby_convoys, rear_convoys = False, True
                adjacent_convoys = []
                if convoy.available_for_merge:
                    for other_convoy in convoy.road.convoys_by_id.values():
                        if other_convoy.id == convoy.id or not other_convoy.available_for_merge: continue
                        if convoy.length + other_convoy.length + self.convoy_gap >= self.max_convoy_length: continue # merged convoy would be too long
                        front_distance = convoy.road.separation(convoy.front, other_convoy.rear)
                        rear_distance = convoy.road.separation(convoy.rear, other_convoy.front)
    
                        if min(abs(front_distance), abs(rear_distance)) <= self.coordination_distance: # convoy is near vehicle
                            nearby_convoys = True
                            #print("nearby_convoy", convoy)
                            if (abs(front_distance) < self.convoy_margin or abs(rear_distance) < self.convoy_margin) or (front_distance > 0 and rear_distance < 0): # convoy is in position to merge already
                                adjacent_convoys.append(other_convoy)
    
                            elif rear_distance > 0 and not adjacent_convoys:
                                # slow down to wait for convoy behind
                                rear_convoys = True
                                convoy.desired_speed = min(convoy.desired_speed, other_convoy.desired_speed - self.convoy_slowdown)
                                for vehicle in convoy.vehicles_by_id.values():
                                    vehicle.desired_speed = convoy.desired_speed
    
                            elif rear_distance > 0 and not adjacent_convoys and not rear_convoys:
                                # slow down to wait for convoy behind
                                convoy.desired_speed = convoy.max_speed()
                                for vehicle in convoy.vehicles_by_id.values():
                                    vehicle.desired_speed = convoy.desired_speed
    
                if nearby_convoys and adjacent_convoys:
                    adjacent_convoys.append(convoy)
                    c_merged.update([t.id for t in adjacent_convoys])
                    new_convoy = convoys.merge_convoys(*adjacent_convoys)
                    self.add_convoy(new_convoy)
                    print(f"S{self._step}/T{self._time} Merging {len(adjacent_convoys):,} convoys into new convoy {new_convoy.id}")
                    print(f"\t[{', '.join(c.id for c in adjacent_convoys)}]")
                    for old_convoy_id in c_merged:
                        self.remove_convoy(old_convoy_id)
                        #del self.convoys_by_id[old_convoy_id]
                    
                        
                    #i = 0
                    #while i < len(self.convoys):
                    #    if self.convoys[i].id in c_merged:
                    #        self.convoys.pop(i)
                    #    else:
                    #        i += 1
                        
                
                elif not nearby_convoys:
                    # no nearby vehicles or convoys so go maximum speed
                    #convoy.desired_speed = min([vehicle.max_speed for vehicle in convoy.vehicles_by_id.values()]) * Train_Speed_Limit_Multiplier
                    convoy.desired_speed = convoy.max_speed
                    
                    gaps_being_adjusted, differential = convoy.adjust_spacing()
                    #
                    #for vehicle in convoy.vehicles_by_id.values():
                    #    vehicle.desired_speed = convoy.desired_speed
        
        c_merged = set()
        
                        
    def run_simulation(self, time_steps=1000, time_step_seconds=1,  **kwargs):
        a_stats = []
        for ts in range(time_steps):
            self._step += 1
            self._time += time_step_seconds
            self.vehicle_logic(time_step_seconds=time_step_seconds, **kwargs)
            self.convoy_logic(time_step_seconds=time_step_seconds, **kwargs)
            
            a_stats.append(
                (self._step, self._time,) + 
                #tuple(self.vehicle_index[vehicle.id] if vehicle else None for vehicle in self.vehicles) +
                tuple(vehicle.position for vehicle in self.vehicles) + 
                tuple(vehicle.speed for vehicle in self.vehicles) + 
                tuple(self.convoy_index[vehicle.convoy.id] if vehicle.convoy else None for vehicle in self.vehicles)
            )
        
        df_stats = pd.DataFrame(
            a_stats,
            columns=[
                "step", "time"
            #] + [
            #    f"v_idx_{i}" for i in range(len(self.vehicles))
            ] + [
                f"v_pos_{i}" for i in range(len(self.vehicles))
            ] + [
                f"v_spd_{i}" for i in range(len(self.vehicles))
            ] + [
                f"v_cnv_{i}" for i in range(len(self.vehicles))
            ]
        )
        return df_stats
    