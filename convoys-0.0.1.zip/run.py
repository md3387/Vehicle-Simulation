﻿import random
import pandas as pd
from enum import Enum
from datetime import datetime, timedelta
import uuid
import numpy as np
import math

try:
    from . import roads, vehicles, convoys
    from . import simulation
except ImportError:
    import roads, vehicles, convoys
    import simulation

if __name__ == "__main__":
    
    # load simulator
    print("Loading simulator")
    simulator = simulation.Simulator()
    
    # initialize roads - example is 1 circular track, 20km long
    roads = simulator.initialize_roads(
        num_roads=1,
        road_lengths=20000,
        roads_circular=True
    )
    print(f"\n{len(roads):,} Roads:")
    print('\n\t'.join(str(road) for road in roads))
    
    # initialize vehicles and scatter them at various entrance ramps
    # give some vehicles destination off ramps and leave others to loop
    vehicles = simulator.initialize_vehicles(
        num_vehicles=10,
        destination_probability=0.5,
    )
    print(f"\n{len(vehicles):,} Vehicles:")
    print('\n\t'.join(str(vehicle) for vehicle in vehicles))
    
    print(f"\n{len(simulator.entrance_ramps):,} EntranceRamps:")
    print('\n\t'.join(str(ramp) for ramp in simulator.entrance_ramps))
    
    print("\n\nStarting simulation")
    df = simulator.run_simulation(
        time_steps=20000, time_step_seconds=0.25)

    excel_file_path = "vehicle_positions_and_speeds.xlsx"
    df.to_excel(excel_file_path, index=False)
    print(f"Data saved to {excel_file_path}")

    